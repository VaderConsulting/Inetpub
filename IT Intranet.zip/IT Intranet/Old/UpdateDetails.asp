<%@Language = VBScript%>
<!-- #Include file="Includes/Menu.asp" -->
<%
Function Check(Current)
	If Current = CurrentCountryCode Then
		Check = "Selected"
	Else
		Check = ""
	End If
End Function

	response.expires = 0

	'CONST ServiceAccount = "Intranet\Mark"
	'CONST ServicePassword = "xxxxx"
	Dim ServiceAccount
	ServiceAccount = Application("ADServiceAccount")		'"OXIANA\svc-itintranet"
	Dim ServicePassword
	ServicePassword = Application("ADServicePassword")	'"45.Pr4D0"

	Const ADS_SECURE_AUTHENTICATION = 1
	Const ADS_USE_ENCRYPTION = 2
	Const ADS_PROPERTY_CLEAR = 1

	'Define the local variables
	Dim lstrUserAccount
	Dim lstrDisplayUser
	Dim llngCounter
	Dim lstrErrorMessage
	Dim lblnHideFields
	Dim CurrentCountryCode
	
	'define the recordset objects
	Dim adoConn
	Dim adoCmd
	Dim adoRS
	
	'Grab the users account details
	lstrUserAccount = UCASE(Request.ServerVariables("LOGON_USER"))
	lstrDisplayUser = UCASE(Replace(lstrUserAccount, "OXIANA\", ""))
	
	'check if the user has posted some information back
	If (len(request.form("ADSPath")) > 0) Then
		
		'The user has changed their information, so update AD
		Dim lstrTelephoneNumber
		Dim lstrCompany
		Dim lstrSt
		Dim lstrHomePhone
		Dim lstrStreetAddress
		Dim lstrFacsimileTelephoneNumber
		Dim lstrDescription
		Dim lstrPostalCode
		Dim lstrPhysicalDeliveryOfficeName
		Dim lstrMobile
		Dim lstrL
		Dim lstrTitle
		Dim lstrDepartment
		Dim lstrCountryCode
		
		'grab the users new details and make sure that they have entered valid data
		lstrTelephoneNumber = Request.Form("TelephoneNumber")
		lstrCompany = Request.Form("Company")
		lstrSt = Request.Form("St")
		lstrStreetAddress = Request.Form("StreetAddress")
		lstrFacsimileTelephoneNumber = Request.Form("FacsimileTelephoneNumber")
		lstrDescription = Request.Form("Description")
		lstrPostalCode = Request.Form("PostalCode")
		lstrPhysicalDeliveryOfficeName = Request.Form("PhysicalDeliveryOfficeName")
		lstrMobile = Request.Form("Mobile")
		lstrL = Request.Form("L")
		lstrTitle = Request.Form("Title")
		lstrDepartment = Request.Form("Department")
		lstrCountryCode = Request.Form("CountryCode")

		
		'define the loval variables/objects
		Dim objLDAPProvider
		Dim objUser
		
		'create the LDAP Provider object
		Set objLDAPProvider = GetObject("LDAP:")
		
		'locate the AD user for editing
		Set objUser = objLDAPProvider.OpenDSObject(Request.Form("ADSPath"), ServiceAccount, ServicePassword, ADS_SECURE_AUTHENTICATION)
		
		'save the new information into AD
		If Len(lstrTelephoneNumber) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "telephoneNumber", vbNull
		Else
			objUser.TelephoneNumber = lstrTelephoneNumber
		End If
		If Len(lstrCompany) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "Company", vbNullString
		Else
			objUser.Company = lstrCompany
		End If
		If Len(lstrSt) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "st", vbNullString
		Else
			objUser.St = lstrSt
		End If
		If Len(lstrStreetAddress) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "StreetAddress", vbNullString
		Else
			objUser.StreetAddress = lstrStreetAddress
		End If
		If Len(lstrFacsimileTelephoneNumber) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "FacsimileTelephoneNumber", vbNullString
		Else
			objUser.FacsimileTelephoneNumber = lstrFacsimileTelephoneNumber
		End If
		If Len(Trim(lstrDescription)) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "Description", vbNullString
		Else
			objUser.Description = lstrDescription
		End If
		If Len(lstrPostalCode) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "PostalCode", vbNullString
		Else
			objUser.PostalCode = lstrPostalCode
		End If
		If Len(lstrPhysicalDeliveryOfficeName) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "PhysicalDeliveryOfficeName", vbNullString
		Else
			objUser.PhysicalDeliveryOfficeName = lstrPhysicalDeliveryOfficeName
		End If
		If Len(lstrMobile) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "Mobile", vbNullString
		Else
			objUser.Mobile = lstrMobile
		End If
		If Len(lstrL) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "L", vbNullString
		Else
			objUser.L = lstrL
		End If
		If Len(lstrTitle) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "Title", vbNullString
		Else
			objUser.Title = lstrTitle
		End If
		If Len(lstrDepartment) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "Department", vbNullString
		Else
			objUser.Department = lstrDepartment
		End If
		If Len(lstrCountryCode) = 0 Then
			objUser.PutEx ADS_PROPERTY_CLEAR, "CountryCode", vbNullString
		Else
			objUser.CountryCode = lstrCountryCode
		End If

		'apply the changes
		On Error Resume Next
		objUser.SetInfo
		If (Err.Number <> 0) Then
		  lstrErrorMessage = "<SPAN style=""COLOR:#FF0000"">An error was encountered while trying to update the AD database. Please contact an administrator.</SPAN><BR><BR>"
		  lstrErrorMessage = lstrErrorMessage + "<!-- (" + CStr(Err.Number) + ") " + Err.Description + " -->"
		  Err.Clear
		Else
   		lstrErrorMessage = "<SPAN style=""COLOR:#FF0000"">Your Active Directory details were successfully updated.</SPAN><BR><BR>"
		End If
		On Error Goto 0
		
		'release the objects
		Set objUser = Nothing
		Set objLDAPProvider = Nothing
		
	End If 

	'create the connection object
	Set adoConn = CreateObject("ADODB.Connection")
	
	'Attempt to locate the user account in AD
	adoConn.Provider = "ADsDSOObject"
	adoConn.Properties("User ID") = ServiceAccount
	adoConn.Properties("Password") = ServicePassword
	adoConn.Properties("ADSI Flag") = 1
	adoConn.Properties("Encrypt Password") = True
	adoConn.Open "ADSI"
	Set adoCmd = CreateObject("ADODB.Command")
	Set adoCmd.ActiveConnection = adoConn
	adoCmd.CommandText = "<LDAP://DC=Oxiana,DC=com,DC=au>;(&(objectCategory=user)(sAMAccountName=" + lstrDisplayUser + "));ADsPath,CN,givenName,mail,sn,telephoneNumber,company,st,streetAddress,facsimileTelephoneNumber,description,postalcode,physicalDeliveryOfficeName,mobile,l,title,Department,countryCode;subtree"
	On Error Resume Next
	Set adoRS = adoCmd.Execute
	On Error Goto 0
	If UCase(typename(adoRS)) = "EMPTY" Then
		lstrErrorMessage = "<SPAN style=""COLOR:#FF0000"">An error was encountered while trying to connect to the AD database. Please contact an administrator.</SPAN>"
		lblnHideFields = True
	ElseIf adoRS.EOF Then
		lstrErrorMessage = "<SPAN style=""COLOR:#FF0000"">The specified user account could not be found.</SPAN>" + "<!-- " + adoCmd.CommandText + " -->"
		lblnHideFields = True
	else
		CurrentCountryCode = adoRS.Fields("CountryCode")
	End If
%>
<HTML>
<HEAD>
	<TITLE>IT Intranet: Update My Details</TITLE>
	<link rel="stylesheet" href="Styles/Style.css" type="text/css"></link>
	<SCRIPT language=JavaScript>
	<!--
	function HideNonPrintables()
	{
		for (Counter=0;Counter<HidePrint.length;Counter++) HidePrint[Counter].style.display = 'None';
	}
	function ShowNonPrintables()
	{
		for (Counter=0;Counter<HidePrint.length;Counter++) HidePrint[Counter].style.display = 'Inline';
	}
	//-->
	</SCRIPT>
</HEAD>

<BODY onbeforeprint="HideNonPrintables()" onafterprint="ShowNonPrintables()">
	<TABLE width=770 cellpadding=0 cellspacing=0 align=center width=770>
		<TR id=HidePrint height=79><TD colspan=3 background=Images/Logo.gif align=right class=Copyright><A href="SiteMap.asp">Site Map</A><IMG align="absmiddle" width=19 height=12 src="Images/PrivacyDivider.gif"><A href="ContactUs.asp">Contact Us</A></TD></TR>
		<TR id=HidePrint><TD colspan=3><IMG height=11 width=770 src="Images/DottedLine.gif"></TD></TR>
		<TR id=HidePrint>
			<TD width=190><DIV class=HomeLink><A href="index.asp" width=100%>HOME</A></DIV></TD>
			<TD width=10>&nbsp;</TD>
			<TD width=570>&nbsp;</TD>
		</TR>
		<TR id=HidePrint><TD colspan=3><IMG height=11 width=770 src="Images/DottedLine.gif"></TD></TR>
		<TR>
			<TD id=HidePrint width=190 valign=top>
				<TABLE cellpadding=0 cellspacing=0 width=100%>
					<%ShowMenu%>
				</TABLE>
			</TD>
			<TD width=10></TD>
			<TD width=570 valign=top>
				<SPAN class=MainHeading style="display:inline;width:460px; height:21px">Update My Details</SPAN><SPAN class=Copyright style="padding-top:6px;padding-right:25px;display:inline;width:110px;HEIGHT:21px;cursor:hand;BACKGROUND-IMAGE:url('Images/PrintArrow.gif')" onclick="window.print()">Print this page</SPAN><BR><BR>
				
				<%= lstrErrorMessage%>
				
				<%If lblnHideFields <>  True Then%>
				Please check the following fields to ensure that your details are correctly entered. The information contained here will be used in the OXIANA Global Address Book.
				<FORM action="UpdateDetails.asp" method=post>
					<TABLE cellpadding=0 cellspacing=0>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Account Name:&nbsp;</TD>
							<TD><%= lstrDisplayUser%></TD>
						</TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Given Name:&nbsp;</TD>
							<TD><%= Trim(adoRS.Fields("GivenName"))%></TD>
						</TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Last Name:&nbsp;</TD>
							<TD><%= Trim(adoRS.Fields("SN"))%></TD>
						</TR>
						<TR><TD>&nbsp;</TD></TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Title:&nbsp;</TD>
							<TD><INPUT  name="Title" value="<%= Trim(adoRS.Fields("Title"))%>"></TD>
						</TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Department:&nbsp;</TD>
							<TD><INPUT  name="Department" value="<%= Trim(adoRS.Fields("Department"))%>"></TD>
						</TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Company:&nbsp;</TD>
							<TD>
								<SELECT name=Company>
									<OPTION value="">-- Not Specified --</OPTION>
									<OPTION value="Oxiana" <%If Trim(adoRS.Fields("Company")) = "Oxiana" Then Response.write "Selected" End If%>>Oxiana</OPTION>
									<OPTION value="Empired" <%If Trim(adoRS.Fields("Company")) = "Empired" Then Response.write "Selected" End If%>>Empired</OPTION>
									<OPTION value="Mincom" <%If Trim(adoRS.Fields("Company")) = "Mincom" Then Response.write "Selected" End If%>>Mincom</OPTION>
								</SELECT>
							</TD>
						</TR>
						<TR><TD>&nbsp;</TD></TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Email:&nbsp;</TD>
							<TD><%= Trim(adoRS.Fields("Mail"))%></TD>
						</TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Phone:&nbsp;</TD>
							<TD><INPUT size=10 maxlength=15 name="TelephoneNumber" value="<%= Trim(adoRS.Fields("TelephoneNumber"))%>"></TD>
						</TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Fax:&nbsp;</TD>
							<TD><INPUT size=10 maxlength=15 name="FacsimileTelephoneNumber" value="<%= Trim(adoRS.Fields("FacsimileTelephoneNumber"))%>"></TD>
						</TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Mobile:&nbsp;</TD>
							<TD><INPUT size=12 maxlength=18 name="Mobile" value="<%= Trim(adoRS.Fields("Mobile"))%>"></TD>
						</TR>
						<TR><TD>&nbsp;</TD></TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Street:&nbsp;</TD>
							<TD>
								<INPUT name="StreetAddress" value="<%= Trim(adoRS.Fields("StreetAddress"))%>">
							</TD>
						</TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">City:&nbsp;</TD>
							<TD><INPUT size=20 maxlength=20 name="L" value="<%= Trim(adoRS.Fields("L"))%>"></TD>
						</TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">State:&nbsp;</TD>
							<TD><INPUT size=6 maxlength=4 name="St" value="<%= Trim(adoRS.Fields("St"))%>"></TD>
						</TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Post Code:&nbsp;</TD>
							<TD><INPUT size=6 maxlength=8 name="PostalCode" value="<%= Trim(adoRS.Fields("PostalCode"))%>"></TD>
						</TR>
						<TR>
							<TD class=SubHeading style="TEXT-ALIGN:Right">Country:&nbsp;</TD>
							<TD>
								<SELECT name=CountryCode>
									<OPTION value="">-- Not Specified --</OPTION>
									<OPTION value="4" <%=Check(4)%>>Afghanistan</OPTION>
									<OPTION value="8" <%=Check(8)%>>Albania, People's Socialist Republic of</OPTION>
									<OPTION value="12" <%=Check(12)%>>Algeria, People's Democratic Republic of</OPTION>
									<OPTION value="16" <%=Check(16)%>>American Samoa</OPTION>
									<OPTION value="20" <%=Check(20)%>>Andorra, Principality of</OPTION>
									<OPTION value="24" <%=Check(24)%>>Angola, Republic of</OPTION>
									<OPTION value="660" <%=Check(660)%>>Anguilla</OPTION>
									<OPTION value="10" <%=Check(10)%>>Antarctica (the territory South of 60 deg S)</OPTION>
									<OPTION value="28" <%=Check(28)%>>Antigua and Barbuda</OPTION>
									<OPTION value="32" <%=Check(32)%>>Argentina, Argentine Republic</OPTION>
									<OPTION value="51" <%=Check(51)%>>Armenia</OPTION>
									<OPTION value="533" <%=Check(533)%>>Aruba</OPTION>
									<OPTION value="36" <%=Check(36)%>>Australia, Commonwealth of</OPTION>
									<OPTION value="40" <%=Check(40)%>>Austria, Republic of</OPTION>
									<OPTION value="31" <%=Check(31)%>>Azerbaijan, Republic of</OPTION>
									<OPTION value="44" <%=Check(44)%>>Bahamas, Commonwealth of the</OPTION>
									<OPTION value="48" <%=Check(48)%>>Bahrain, Kingdom of</OPTION>
									<OPTION value="50" <%=Check(50)%>>Bangladesh, People's Republic of</OPTION>
									<OPTION value="52" <%=Check(52)%>>Barbados</OPTION>
									<OPTION value="112" <%=Check(112)%>>Belarus</OPTION>
									<OPTION value="56" <%=Check(56)%>>Belgium, Kingdom of</OPTION>
									<OPTION value="84" <%=Check(84)%>>Belize</OPTION>
									<OPTION value="204" <%=Check(204)%>>Benin, People's Republic of</OPTION>
									<OPTION value="60" <%=Check(60)%>>Bermuda</OPTION>
									<OPTION value="64" <%=Check(64)%>>Bhutan, Kingdom of</OPTION>
									<OPTION value="68" <%=Check(68)%>>Bolivia, Republic of</OPTION>
									<OPTION value="70" <%=Check(70)%>>Bosnia and Herzegovina</OPTION>
									<OPTION value="72" <%=Check(72)%>>Botswana, Republic of</OPTION>
									<OPTION value="74" <%=Check(74)%>>Bouvet Island (Bouvetoya)</OPTION>
									<OPTION value="76" <%=Check(76)%>>Brazil, Federative Republic of</OPTION>
									<OPTION value="86" <%=Check(86)%>>British Indian Ocean Territory (Chagos Archipelago)</OPTION>
									<OPTION value="92" <%=Check(92)%>>British Virgin Islands</OPTION>
									<OPTION value="96" <%=Check(96)%>>Brunei Darussalam</OPTION>
									<OPTION value="100" <%=Check(100)%>>Bulgaria, People's Republic of</OPTION>
									<OPTION value="854" <%=Check(854)%>>Burkina Faso</OPTION>
									<OPTION value="108" <%=Check(108)%>>Burundi, Republic of</OPTION>
									<OPTION value="116" <%=Check(116)%>>Cambodia, Kingdom of</OPTION>
									<OPTION value="120" <%=Check(120)%>>Cameroon, United Republic of</OPTION>
									<OPTION value="124" <%=Check(124)%>>Canada</OPTION>
									<OPTION value="132" <%=Check(132)%>>Cape Verde, Republic of</OPTION>
									<OPTION value="136" <%=Check(136)%>>Cayman Islands</OPTION>
									<OPTION value="140" <%=Check(140)%>>Central African Republic</OPTION>
									<OPTION value="148" <%=Check(148)%>>Chad, Republic of</OPTION>
									<OPTION value="152" <%=Check(152)%>>Chile, Republic of</OPTION>
									<OPTION value="156" <%=Check(156)%>>China, People's Republic of</OPTION>
									<OPTION value="162" <%=Check(162)%>>Christmas Island</OPTION>
									<OPTION value="166" <%=Check(166)%>>Cocos (Keeling) Islands</OPTION>
									<OPTION value="170" <%=Check(170)%>>Colombia, Republic of</OPTION>
									<OPTION value="174" <%=Check(174)%>>Comoros, Union of the</OPTION>
									<OPTION value="180" <%=Check(180)%>>Congo, Democratic Republic of</OPTION>
									<OPTION value="178" <%=Check(178)%>>Congo, People's Republic of</OPTION>
									<OPTION value="184" <%=Check(184)%>>Cook Islands</OPTION>
									<OPTION value="188" <%=Check(188)%>>Costa Rica, Republic of</OPTION>
									<OPTION value="384" <%=Check(384)%>>Cote D'Ivoire, Ivory Coast, Republic of the</OPTION>
									<OPTION value="192" <%=Check(192)%>>Cuba, Republic of</OPTION>
									<OPTION value="196" <%=Check(196)%>>Cyprus, Republic of</OPTION>
									<OPTION value="203" <%=Check(203)%>>Czech Republic</OPTION>
									<OPTION value="208" <%=Check(208)%>>Denmark, Kingdom of</OPTION>
									<OPTION value="262" <%=Check(262)%>>Djibouti, Republic of</OPTION>
									<OPTION value="212" <%=Check(212)%>>Dominica, Commonwealth of</OPTION>
									<OPTION value="214" <%=Check(214)%>>Dominican Republic</OPTION>
									<OPTION value="218" <%=Check(218)%>>Ecuador, Republic of</OPTION>
									<OPTION value="818" <%=Check(818)%>>Egypt, Arab Republic of</OPTION>
									<OPTION value="222" <%=Check(222)%>>El Salvador, Republic of</OPTION>
									<OPTION value="226" <%=Check(226)%>>Equatorial Guinea, Republic of</OPTION>
									<OPTION value="232" <%=Check(232)%>>Eritrea</OPTION>
									<OPTION value="233" <%=Check(233)%>>Estonia</OPTION>
									<OPTION value="231" <%=Check(231)%>>Ethiopia</OPTION>
									<OPTION value="234" <%=Check(234)%>>Faeroe Islands</OPTION>
									<OPTION value="238" <%=Check(238)%>>Falkland Islands (Malvinas)</OPTION>
									<OPTION value="242" <%=Check(242)%>>Fiji, Republic of the Fiji Islands</OPTION>
									<OPTION value="246" <%=Check(246)%>>Finland, Republic of</OPTION>
									<OPTION value="250" <%=Check(250)%>>France, French Republic</OPTION>
									<OPTION value="254" <%=Check(254)%>>French Guiana</OPTION>
									<OPTION value="258" <%=Check(258)%>>French Polynesia</OPTION>
									<OPTION value="260" <%=Check(260)%>>French Southern Territories</OPTION>
									<OPTION value="266" <%=Check(266)%>>Gabon, Gabonese Republic</OPTION>
									<OPTION value="270" <%=Check(270)%>>Gambia, Republic of the</OPTION>
									<OPTION value="268" <%=Check(268)%>>Georgia</OPTION>
									<OPTION value="276" <%=Check(276)%>>Germany</OPTION>
									<OPTION value="288" <%=Check(288)%>>Ghana, Republic of</OPTION>
									<OPTION value="292" <%=Check(292)%>>Gibraltar</OPTION>
									<OPTION value="300" <%=Check(300)%>>Greece, Hellenic Republic</OPTION>
									<OPTION value="304" <%=Check(304)%>>Greenland</OPTION>
									<OPTION value="308" <%=Check(308)%>>Grenada</OPTION>
									<OPTION value="312" <%=Check(312)%>>Guadaloupe</OPTION>
									<OPTION value="316" <%=Check(316)%>>Guam</OPTION>
									<OPTION value="320" <%=Check(320)%>>Guatemala, Republic of</OPTION>
									<OPTION value="324" <%=Check(324)%>>Guinea, Revolutionary People's Rep'c of</OPTION>
									<OPTION value="624" <%=Check(624)%>>Guinea-Bissau, Republic of</OPTION>
									<OPTION value="328" <%=Check(328)%>>Guyana, Republic of</OPTION>
									<OPTION value="332" <%=Check(332)%>>Haiti, Republic of</OPTION>
									<OPTION value="334" <%=Check(334)%>>Heard and McDonald Islands</OPTION>
									<OPTION value="336" <%=Check(336)%>>Holy See (Vatican City State)</OPTION>
									<OPTION value="340" <%=Check(340)%>>Honduras, Republic of</OPTION>
									<OPTION value="344" <%=Check(344)%>>Hong Kong, Special Administrative Region of China</OPTION>
									<OPTION value="191" <%=Check(191)%>>Hrvatska (Croatia)</OPTION>
									<OPTION value="348" <%=Check(348)%>>Hungary, Hungarian People's Republic</OPTION>
									<OPTION value="352" <%=Check(352)%>>Iceland, Republic of</OPTION>
									<OPTION value="356" <%=Check(356)%>>India, Republic of</OPTION>
									<OPTION value="360" <%=Check(360)%>>Indonesia, Republic of</OPTION>
									<OPTION value="364" <%=Check(364)%>>Iran, Islamic Republic of</OPTION>
									<OPTION value="368" <%=Check(368)%>>Iraq, Republic of</OPTION>
									<OPTION value="372" <%=Check(372)%>>Ireland</OPTION>
									<OPTION value="376" <%=Check(376)%>>Israel, State of</OPTION>
									<OPTION value="380" <%=Check(380)%>>Italy, Italian Republic</OPTION>
									<OPTION value="388" <%=Check(388)%>>Jamaica</OPTION>
									<OPTION value="392" <%=Check(392)%>>Japan</OPTION>
									<OPTION value="400" <%=Check(400)%>>Jordan, Hashemite Kingdom of</OPTION>
									<OPTION value="398" <%=Check(398)%>>Kazakhstan, Republic of</OPTION>
									<OPTION value="404" <%=Check(404)%>>Kenya, Republic of</OPTION>
									<OPTION value="296" <%=Check(296)%>>Kiribati, Republic of</OPTION>
									<OPTION value="408" <%=Check(408)%>>Korea, Democratic People's Republic of</OPTION>
									<OPTION value="410" <%=Check(410)%>>Korea, Republic of</OPTION>
									<OPTION value="414" <%=Check(414)%>>Kuwait, State of</OPTION>
									<OPTION value="417" <%=Check(417)%>>Kyrgyz Republic</OPTION>
									<OPTION value="418" <%=Check(418)%>>Lao People's Democratic Republic</OPTION>
									<OPTION value="428" <%=Check(428)%>>Latvia</OPTION>
									<OPTION value="422" <%=Check(422)%>>Lebanon, Lebanese Republic</OPTION>
									<OPTION value="426" <%=Check(426)%>>Lesotho, Kingdom of</OPTION>
									<OPTION value="430" <%=Check(430)%>>Liberia, Republic of</OPTION>
									<OPTION value="434" <%=Check(434)%>>Libyan Arab Jamahiriya</OPTION>
									<OPTION value="438" <%=Check(438)%>>Liechtenstein, Principality of</OPTION>
									<OPTION value="440" <%=Check(440)%>>Lithuania</OPTION>
									<OPTION value="442" <%=Check(442)%>>Luxembourg, Grand Duchy of</OPTION>
									<OPTION value="446" <%=Check(446)%>>Macao, Special Administrative Region of China</OPTION>
									<OPTION value="807" <%=Check(807)%>>Macedonia, the former Yugoslav Republic of</OPTION>
									<OPTION value="450" <%=Check(450)%>>Madagascar, Republic of</OPTION>
									<OPTION value="454" <%=Check(454)%>>Malawi, Republic of</OPTION>
									<OPTION value="458" <%=Check(458)%>>Malaysia</OPTION>
									<OPTION value="462" <%=Check(462)%>>Maldives, Republic of</OPTION>
									<OPTION value="466" <%=Check(466)%>>Mali, Republic of</OPTION>
									<OPTION value="470" <%=Check(470)%>>Malta, Republic of</OPTION>
									<OPTION value="584" <%=Check(584)%>>Marshall Islands</OPTION>
									<OPTION value="474" <%=Check(474)%>>Martinique</OPTION>
									<OPTION value="478" <%=Check(478)%>>Mauritania, Islamic Republic of</OPTION>
									<OPTION value="480" <%=Check(480)%>>Mauritius</OPTION>
									<OPTION value="175" <%=Check(175)%>>Mayotte</OPTION>
									<OPTION value="484" <%=Check(484)%>>Mexico, United Mexican States</OPTION>
									<OPTION value="583" <%=Check(583)%>>Micronesia, Federated States of</OPTION>
									<OPTION value="498" <%=Check(498)%>>Moldova, Republic of</OPTION>
									<OPTION value="492" <%=Check(492)%>>Monaco, Principality of</OPTION>
									<OPTION value="496" <%=Check(496)%>>Mongolia, Mongolian People's Republic</OPTION>
									<OPTION value="500" <%=Check(500)%>>Montserrat</OPTION>
									<OPTION value="504" <%=Check(504)%>>Morocco, Kingdom of</OPTION>
									<OPTION value="508" <%=Check(508)%>>Mozambique, People's Republic of</OPTION>
									<OPTION value="104" <%=Check(104)%>>Myanmar</OPTION>
									<OPTION value="516" <%=Check(516)%>>Namibia</OPTION>
									<OPTION value="520" <%=Check(520)%>>Nauru, Republic of</OPTION>
									<OPTION value="524" <%=Check(524)%>>Nepal, Kingdom of</OPTION>
									<OPTION value="530" <%=Check(530)%>>Netherlands Antilles</OPTION>
									<OPTION value="528" <%=Check(528)%>>Netherlands, Kingdom of the</OPTION>
									<OPTION value="540" <%=Check(540)%>>New Caledonia</OPTION>
									<OPTION value="554" <%=Check(554)%>>New Zealand</OPTION>
									<OPTION value="558" <%=Check(558)%>>Nicaragua, Republic of</OPTION>
									<OPTION value="562" <%=Check(562)%>>Niger, Republic of the</OPTION>
									<OPTION value="566" <%=Check(566)%>>Nigeria, Federal Republic of</OPTION>
									<OPTION value="570" <%=Check(570)%>>Niue, Republic of</OPTION>
									<OPTION value="574" <%=Check(574)%>>Norfolk Island</OPTION>
									<OPTION value="580" <%=Check(580)%>>Northern Mariana Islands</OPTION>
									<OPTION value="578" <%=Check(578)%>>Norway, Kingdom of</OPTION>
									<OPTION value="512" <%=Check(512)%>>Oman, Sultanate of</OPTION>
									<OPTION value="586" <%=Check(586)%>>Pakistan, Islamic Republic of</OPTION>
									<OPTION value="585" <%=Check(585)%>>Palau</OPTION>
									<OPTION value="275" <%=Check(275)%>>Palestinian Territory, Occupied</OPTION>
									<OPTION value="591" <%=Check(591)%>>Panama, Republic of</OPTION>
									<OPTION value="598" <%=Check(598)%>>Papua New Guinea</OPTION>
									<OPTION value="600" <%=Check(600)%>>Paraguay, Republic of</OPTION>
									<OPTION value="604" <%=Check(604)%>>Peru, Republic of</OPTION>
									<OPTION value="608" <%=Check(608)%>>Philippines, Republic of the</OPTION>
									<OPTION value="612" <%=Check(612)%>>Pitcairn Island</OPTION>
									<OPTION value="616" <%=Check(616)%>>Poland, Polish People's Republic</OPTION>
									<OPTION value="620" <%=Check(620)%>>Portugal, Portuguese Republic</OPTION>
									<OPTION value="630" <%=Check(630)%>>Puerto Rico</OPTION>
									<OPTION value="634" <%=Check(634)%>>Qatar, State of</OPTION>
									<OPTION value="638" <%=Check(638)%>>Reunion</OPTION>
									<OPTION value="642" <%=Check(642)%>>Romania, Socialist Republic of</OPTION>
									<OPTION value="643" <%=Check(643)%>>Russian Federation</OPTION>
									<OPTION value="646" <%=Check(646)%>>Rwanda, Rwandese Republic</OPTION>
									<OPTION value="882" <%=Check(882)%>>Samoa, Independent State of</OPTION>
									<OPTION value="674" <%=Check(674)%>>San Marino, Republic of</OPTION>
									<OPTION value="678" <%=Check(678)%>>Sao Tome and Principe, Democratic Republic of</OPTION>
									<OPTION value="682" <%=Check(682)%>>Saudi Arabia, Kingdom of</OPTION>
									<OPTION value="686" <%=Check(686)%>>Senegal, Republic of</OPTION>
									<OPTION value="891" <%=Check(891)%>>Serbia and Montenegro</OPTION>
									<OPTION value="690" <%=Check(690)%>>Seychelles, Republic of</OPTION>
									<OPTION value="694" <%=Check(694)%>>Sierra Leone, Republic of</OPTION>
									<OPTION value="702" <%=Check(702)%>>Singapore, Republic of</OPTION>
									<OPTION value="703" <%=Check(703)%>>Slovakia (Slovak Republic)</OPTION>
									<OPTION value="705" <%=Check(705)%>>Slovenia</OPTION>
									<OPTION value="90" <%=Check(90)%>>Solomon Islands</OPTION>
									<OPTION value="706" <%=Check(706)%>>Somalia, Somali Republic</OPTION>
									<OPTION value="710" <%=Check(710)%>>South Africa, Republic of</OPTION>
									<OPTION value="239" <%=Check(239)%>>South Georgia and the South Sandwich Islands</OPTION>
									<OPTION value="724" <%=Check(724)%>>Spain, Spanish State</OPTION>
									<OPTION value="144" <%=Check(144)%>>Sri Lanka, Democratic Socialist Republic of</OPTION>
									<OPTION value="654" <%=Check(654)%>>St. Helena</OPTION>
									<OPTION value="659" <%=Check(659)%>>St. Kitts and Nevis</OPTION>
									<OPTION value="662" <%=Check(662)%>>St. Lucia</OPTION>
									<OPTION value="666" <%=Check(666)%>>St. Pierre and Miquelon</OPTION>
									<OPTION value="670" <%=Check(670)%>>St. Vincent and the Grenadines</OPTION>
									<OPTION value="736" <%=Check(736)%>>Sudan, Democratic Republic of the</OPTION>
									<OPTION value="740" <%=Check(740)%>>Suriname, Republic of</OPTION>
									<OPTION value="744" <%=Check(744)%>>Svalbard & Jan Mayen Islands</OPTION>
									<OPTION value="748" <%=Check(748)%>>Swaziland, Kingdom of</OPTION>
									<OPTION value="752" <%=Check(752)%>>Sweden, Kingdom of</OPTION>
									<OPTION value="756" <%=Check(756)%>>Switzerland, Swiss Confederation</OPTION>
									<OPTION value="760" <%=Check(760)%>>Syrian Arab Republic</OPTION>
									<OPTION value="158" <%=Check(158)%>>Taiwan, Province of China</OPTION>
									<OPTION value="762" <%=Check(762)%>>Tajikistan</OPTION>
									<OPTION value="834" <%=Check(834)%>>Tanzania, United Republic of</OPTION>
									<OPTION value="764" <%=Check(764)%>>Thailand, Kingdom of</OPTION>
									<OPTION value="626" <%=Check(626)%>>Timor-Leste, Democratic Republic of</OPTION>
									<OPTION value="768" <%=Check(768)%>>Togo, Togolese Republic</OPTION>
									<OPTION value="772" <%=Check(772)%>>Tokelau (Tokelau Islands)</OPTION>
									<OPTION value="776" <%=Check(776)%>>Tonga, Kingdom of</OPTION>
									<OPTION value="780" <%=Check(780)%>>Trinidad and Tobago, Republic of</OPTION>
									<OPTION value="788" <%=Check(788)%>>Tunisia, Republic of</OPTION>
									<OPTION value="792" <%=Check(792)%>>Turkey, Republic of</OPTION>
									<OPTION value="795" <%=Check(795)%>>Turkmenistan</OPTION>
									<OPTION value="796" <%=Check(796)%>>Turks and Caicos Islands</OPTION>
									<OPTION value="798" <%=Check(798)%>>Tuvalu</OPTION>
									<OPTION value="800" <%=Check(800)%>>Uganda, Republic of</OPTION>
									<OPTION value="804" <%=Check(804)%>>Ukraine</OPTION>
									<OPTION value="784" <%=Check(784)%>>United Arab Emirates</OPTION>
									<OPTION value="826" <%=Check(826)%>>United Kingdom of Great Britain & N. Ireland</OPTION>
									<OPTION value="581" <%=Check(581)%>>United States Minor Outlying Islands</OPTION>
									<OPTION value="840" <%=Check(840)%>>United States of America</OPTION>
									<OPTION value="858" <%=Check(858)%>>Uruguay, Eastern Republic of</OPTION>
									<OPTION value="850" <%=Check(850)%>>US Virgin Islands</OPTION>
									<OPTION value="860" <%=Check(860)%>>Uzbekistan</OPTION>
									<OPTION value="548" <%=Check(548)%>>Vanuatu</OPTION>
									<OPTION value="862" <%=Check(862)%>>Venezuela, Bolivarian Republic of</OPTION>
									<OPTION value="704" <%=Check(704)%>>Viet Nam, Socialist Republic of</OPTION>
									<OPTION value="876" <%=Check(876)%>>Wallis and Futuna Islands</OPTION>
									<OPTION value="732" <%=Check(732)%>>Western Sahara</OPTION>
									<OPTION value="887" <%=Check(887)%>>Yemen</OPTION>
									<OPTION value="894" <%=Check(894)%>>Zambia, Republic of</OPTION>
									<OPTION value="716" <%=Check(716)%>>Zimbabwe</OPTION>
								</SELECT>
							</TD>
						</TR>
						<TR><TD>&nbsp;</TD></TR>
						<TR>
							<TD><INPUT type=hidden name=ADSPath value="<%= adoRS.Fields("ADSPath")%>"></TD>
							<TD><INPUT type=Submit value="Update"></TD>
						</TR>
					</TABLE>
				</FORM>
				<%End If%>
				<DIV class=Copyright><BR>This page last updated: 12 Jun 2006 (Empired)</DIV>
			</TD>
		</TR>
		<TR id=HidePrint><TD colspan=3><IMG height=11 width=770 src="Images/DottedLine.gif"></TD></TR>
		<TR id=HidePrint><TD colspan=3 class=Copyright><A href="IntranetDisclaimer.asp">Disclaimer</A><IMG align="absmiddle" width=19 height=12 src="Images/PrivacyDivider.gif"><A href="IntranetPrivacyStatement.asp">Privacy</A><IMG align="absmiddle" width=19 height=12 src="Images/PrivacyDivider.gif">Copyright Oxiana Limited 2006</TD></TR>
	</TABLE>
</BODY>
</HTML>
<%
	'close the recordset objects
	if UCase(TypeName(adoRS)) <> "EMPTY" Then
		adoRS.Close
	End If
	adoConn.Close
	
	'release the objects
	Set adoRS = Nothing
	Set adoConn = Nothing
%>