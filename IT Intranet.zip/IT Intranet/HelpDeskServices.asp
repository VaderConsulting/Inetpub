<!-- #Include file="Includes/Menu.asp" -->

<HTML>
<HEAD>
	<TITLE>IT Intranet: Help Desk Services</TITLE>
	<link rel="stylesheet" href="Styles/Style.css" type="text/css"></link>
	<SCRIPT language=JavaScript>
	<!--
	function HideNonPrintables()
	{
		for (Counter=0;Counter<HidePrint.length;Counter++) HidePrint[Counter].style.display = 'None';
	}
	function ShowNonPrintables()
	{
		for (Counter=0;Counter<HidePrint.length;Counter++) HidePrint[Counter].style.display = 'Inline';
	}
	//-->
	</SCRIPT>
</HEAD>

<BODY onbeforeprint="HideNonPrintables()" onafterprint="ShowNonPrintables()">
	<TABLE width=770 cellpadding=0 cellspacing=0 align=center width=770>
		<TR id=HidePrint height=79><TD colspan=3 background=Images/Logo.gif align=right class=Copyright><A href="SiteMap.asp">Site Map</A><IMG align="absmiddle" width=19 height=12 src="Images/PrivacyDivider.gif"><A href="ContactUs.asp">Contact Us</A></TD></TR>
		<TR id=HidePrint><TD colspan=3><IMG height=11 width=770 src="Images/DottedLine.gif"></TD></TR>
		<TR id=HidePrint>
			<TD width=190><DIV class=HomeLink><A href="index.asp" width=100%>HOME</A></DIV></TD>
			<TD width=10>&nbsp;</TD>
			<TD width=570>&nbsp;</TD>
		</TR>
		<TR id=HidePrint><TD colspan=3><IMG height=11 width=770 src="Images/DottedLine.gif"></TD></TR>
		<TR>
			<TD id=HidePrint width=190 valign=top>
				<TABLE cellpadding=0 cellspacing=0 width=100%>
					<%ShowMenu%>
				</TABLE>
			</TD>
			<TD width=10></TD>
			<TD width=570 valign=top>
				<SPAN class=MainHeading style="display:inline;width:460px; height:21px">Help Desk Services</SPAN><SPAN class=Copyright style="padding-top:6px;padding-right:25px;display:inline;width:110px;HEIGHT:21px;cursor:hand;BACKGROUND-IMAGE:url('Images/PrintArrow.gif')" onclick="window.print()">Print this page</SPAN>
				
				
				<P>There are various methods of contacting the Helpdesk. A summary of these methods is listed below:</P>
 
				<P><SPAN class=SubHeading>Phone:</SPAN> Our easy to remember number is, <B>1300 OXIANA (1300 694262)</B> from anywhere inside Australia. If you are calling from outside Australia you can still call us but will need to use our international number <B>+61 8 9321 9072</B>.</P>
				<P>The desk is currently manned:</P>
				<TABLE>
					<TR>
						<TD width=200>&nbsp;</TD>
						<TD width=100><B>Weekdays</B></TD>
						<TD width=100><B>Weekends</B></TD>
					</TR>
					<TR>
						<TD><B>Australian Central Daylight Time</B></TD><TD>6:30am � 8:30pm</TD><TD>8:30am � 8:30pm</TD>
					</TR>
					<TR>
						<TD><B>Australian Eastern Daylight Time</B></TD><TD>7am � 9pm</TD><TD>9am � 9pm</TD>
					</TR>
					<TR>
						<TD><B>Australian Eastern Standard Time</B></TD><TD>6am � 8pm</TD><TD>8am � 8pm</TD>
					</TR>
					<TR>
						<TD><B>Australian Western Daylight Time</B></TD><TD>5am � 6pm</TD><TD>6am � 6pm</TD>
					</TR>
				</TABLE>
				
				<P><SPAN class=SubHeading>Voicemail:</SPAN> Outside of the Helpdesk hours there is a voicemail service where you can leave a message that will be actioned when the Helpdesk next opens.</P>
				<P><SPAN class=SubHeading>Email:</SPAN> You can send email 24hrs a day to <A href="mailto:itsupport@oxiana.com.au">itsupport@oxiana.com.au</A> and it will be responded to as quickly as possible. This is a great way of logging non-urgent or 'out of hours' calls. We do not recommend logging <B>urgent</B> calls via email as phones will always take precedence. </P>
				<P><SPAN class=SubHeading>Automatic alerts:</SPAN> Automatically generated alerts are sent from most technical equipment in the event of an outage, so we are able to pro-actively detect any major issues and fix them, hopefully before you even notice there's a problem!</P>
				 
				<P><SPAN class=SubHeading>Self-service:</SPAN> Coming soon! An intranet page where you will be able to log, track and update your own calls via the Oxiana intranet.</P>
				<P>If you have any feedback regarding the helpdesk Services please contact the Helpdesk Manager, Russell Toyn with your comments. <A href="mailto:russell.toyn@oxiana.com.au">russell.toyn@oxiana.com.au</A>

				<DIV class=Copyright><BR>This page last updated: 14 Dec 2006 (Empired)</DIV>
			</TD>
		</TR>
		<TR id=HidePrint><TD colspan=3><IMG height=11 width=770 src="Images/DottedLine.gif"></TD></TR>
		<TR id=HidePrint><TD colspan=3 class=Copyright><A href="IntranetDisclaimer.asp">Disclaimer</A><IMG align="absmiddle" width=19 height=12 src="Images/PrivacyDivider.gif"><A href="IntranetPrivacyStatement.asp">Privacy</A><IMG align="absmiddle" width=19 height=12 src="Images/PrivacyDivider.gif">Copyright Oxiana Limited 2006</TD></TR>
	</TABLE>
</BODY>
</HTML>