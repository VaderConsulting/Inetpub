<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<META HTTP-EQUIV="REFRESH" CONTENT='5'>
<!--#include file="styles.inc"-->
<head>
	<title>Status</title>
</head>

<body>

<br>
<div align='left'>
<%
    Randomize Timer
    Response.Write "<table>" & vbcrlf
    Response.Write "    <tr>" & vbcrlf
    Response.Write "        <td nowrap class='smallblackfont'>&nbsp;<strong>" & int(rnd(1) * 100) & "</strong></td>"
    Response.Write "        <td nowrap class='smallblackfont'>Events</td>" & vbcrlf
    Response.Write "        <td nowrap style='cursor : hand;'><img src='images/edit.gif'></td>" & vbcrlf
    Response.Write "    </tr>" & vbcrlf
    Response.Write "        <td nowrap class='smallblackfont'>&nbsp;<strong>" & int(rnd(1) * 100) & "</strong></td>"
    Response.Write "        <td nowrap class='smallblackfont'>Hosts Down</td>" & vbcrlf
    Response.Write "        <td nowrap style='cursor : hand;'><img src='images/stop.gif'></td>" & vbcrlf
    Response.Write "    </tr>" & vbcrlf
    Response.Write "        <td nowrap class='smallblackfont'>&nbsp;<strong>" & int(rnd(1) * 100) & "</strong></td>"
    Response.Write "        <td nowrap class='smallblackfont'>Failed Backups&nbsp;</td>" & vbcrlf
    Response.Write "        <td nowrap style='cursor : hand;'><img src='images/problem_backup.gif'></td>" & vbcrlf
    'Response.Write "        &nbsp;<strong>" & int(rnd(1) * 100) & "</strong> Events<br>" & vbcrlf
    'Response.Write "        &nbsp;<strong>" & int(rnd(1) * 100) & "</strong> Hosts Down<br>" & vbcrlf
    'Response.Write "        &nbsp;<strong>" & int(rnd(1) * 100) & "</strong> Failed Backups&nbsp;</font><img src='images/problem_backup.gif'>" & vbcrlf
    Response.Write "    </tr>" & vbcrlf
    Response.Write "</table>" & vbcrlf
%>
</div>
</body>
</html>
