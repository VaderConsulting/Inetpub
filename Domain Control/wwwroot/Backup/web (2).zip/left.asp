<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<!--#include file="styles.inc"-->
<head>
	<title>Left Toolbar</title>
</head>

<body>
<br>
<div align='center'>
Context sensitive<br>
Option 1<br>
Option 2<br>
Option 3<br>
Option 4<br>
Option 5<br>
Option 6<br>
Option 7<br>
Option 8<br>
Option 8<br>
Option 10<br>
</div>
<br>
<hr>
<br>
<div align='center'>
<img src='images/info.gif'>&nbsp;<strong>Status</strong><br>
<iframe src='status.asp' name='Status' id='Status' width='100%' height='150' marginwidth='0' marginheight='0' scrolling='no' frameborder='0' border="0">
</iframe>
</div>
</body>
</html>
